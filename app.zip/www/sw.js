const CACHE='cee-iphone-v08';
const CORE=['./','./index.html','./manifest.webmanifest','./privacy.html','./impressum.html','./changelog.html','./icons/icon-192.png','./icons/icon-512.png','./icons/icon-180.png','./assets/cover-hero.webp','./assets/cover-social.jpg', './assets/jason.webp','./assets/lucia.webp','./assets/brian.webp','./assets/mandy.webp','./assets/cal.webp','./assets/lori.webp','./assets/boobie.webp','./assets/dimez.webp','./assets/raul.webp','./assets/dre.webp'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('n01-beta-')||k.startsWith('cee-iphone-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{const r=e.request;if(r.method!=='GET')return;const u=new URL(r.url);if(u.origin!==self.location.origin)return;
if(r.mode==='navigate'){e.respondWith(fetch(r).then(x=>{if(x.ok){const clone=x.clone();caches.open(CACHE).then(c=>c.put('./index.html',clone))}return x}).catch(()=>caches.match(r).then(x=>x||caches.match('./index.html'))));return}
e.respondWith(caches.match(r).then(hit=>hit||fetch(r).then(resp=>{if(resp.ok&&resp.type==='basic'){const copy=resp.clone();caches.open(CACHE).then(c=>c.put(r,copy))}return resp})));});
